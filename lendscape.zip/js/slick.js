$('.reviews__slider').slick({
    dots: true,
    infinite: true,
    speed: 300,
    slidesToShow: 1,
    prevArrow: $('.slider-arrow--left'),
    nextArrow: $('.slider-arrow--right'),
  });